CKEDITOR.config.allowedContent = true; 
